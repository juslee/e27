<div id="left_bar"><!--leftbar menu for each and every page.-->
	<div id="e27giveawaylogo"><img src="http://e27giveaway.10dd.co/img/logo_e27.png" alt="logo_e27giveaway" width="54" height="54" style="margin:10px 0 15px 0" /></div>
	<ul id="mainnav">
		<li><a href="http://e27giveaway.10dd.co/login/dashboard.php" class="dash"  title="Dashboard">Dashboard</a></li>
		<li><a href="http://e27giveaway.10dd.co/login/CMS.php" class="cms"  title="CMS">CMS</a></li>
		<li><a href="http://e27giveaway.10dd.co/login/login_index.php" class="useradmin"  title="Users">Users</a></li>
	
	</ul>
	<div class="clear"></div>
	
	<a href="http://e27giveaway.10dd.co/login/logout.php" id="logout">Logout</a>
</div>