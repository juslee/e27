<?php 

include("dbcon.php");
//delete giveaway_id from both giveaway and userURL tables.
if(isset($_POST['id'])){
   $id=$_POST['id'];
   
   
   $sql = "delete from giveaway where giveaway_id='$id'";
   mysql_query($sql);
   $sql1= "delete from userURL where giveaway_id='$id'";
   mysql_query($sql1);
   $sql2= "delete from stattracker where userURL_id='$id'";
   mysql_query($sql2);
  
}
 

?>


<li class='record'><?php echo $r['giveaway_name'];?><a href='#' id="<?php echo $r['giveaway_id'];?>" class='edit'></a><a href='#' id="<?php echo $r['giveaway_id'];?>" class='delbutton'> </a></li>