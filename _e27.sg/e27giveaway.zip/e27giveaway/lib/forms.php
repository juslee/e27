<div id="form_userlogin"><!--need for the login module.-->
	<form action="index.php" method="post" id="form_login" autocomplete="off">
		<ul id="loginform">
			<li class="header"><h5>Sign-in to your account</h5></li>
			<li><label for="username">username</label><input type="text" name="username" id="username" /></li>
			<li><label for="password">password</label><input type="password" name="password" id="password"/></li>
			<li><input type="submit" name="submit" value="Login" id="loginbutton"/></li>
			<li><a href="login/forgot.php" id="forgotpass">Forgot Password</a></li>			
		</ul>
		<div class="clear"></div>
	</form>
</div>
<div id="form_userregister">
	<form action="../login/register.php" method="post" id="register">
		<ul id="registerform">
			<li class="header"><h5>Create a new account</h5></li>
			<li><label for="username">username</label><input type="text" name="username" id="username" /></li>
			<li><label for="password">password</label><input type="password" name="password" id="password"/></li>
			<li><label for="passconf">confirm password</label><input type="password" name="passconf" id="passconf"/></li>
			<li><label for="email">email</label><input type="text" name="email" id="email"/></li>
			<li><input type="submit" name="register" value="Register" id="registerbutton" class="register"/></li>
			<li><a href="login/forgot.php" id="forgotpass">Forgot Password</a></li>			
		</ul>
		<div class="clear"></div>
	</form>
</div>
<div id="form_userforgotpass"></div>