<?php
include("dbcon.php");

if(isset($_POST['giveaway_id'])) 
{
$giveaway_id 				=$_POST['giveaway_id'];
$giveaway_name				=$_POST['giveaway_name'];
$giveaway_description		=$_POST['giveaway_description'];
$giveaway_benefits			=$_POST['giveaway_benefits'];
$giveaway_prize_description	=$_POST['giveaway_prize_description'];
$giveaway_question			=$_POST['giveaway_question'];
$giveaway_start_date		=$_POST['giveaway_start_date'];
$giveaway_end_date			=$_POST['giveaway_end_date'];
$giveaway_legal				=$_POST['giveaway_legal'];



$sql = "UPDATE giveaway	SET  giveaway_name='".$giveaway_name."',giveaway_description='".$giveaway_description."',giveaway_benefits='".$giveaway_benefits."',giveaway_prize_description='".$giveaway_prize_description."',giveaway_question='".$giveaway_question."',giveaway_start_date='".$giveaway_start_date."',giveaway_end_date='".$giveaway_end_date."',giveaway_legal='".$giveaway_legal."'	WHERE giveaway_id='".$giveaway_id."' ";

mysql_query($sql);
}else { 
echo "not success";
}

?>

