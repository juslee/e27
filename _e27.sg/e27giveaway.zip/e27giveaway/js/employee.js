
	$(document).ready(function() {
		//this section controls the click of the input divs so we can edit
		$(".edit_tr").click(function() {
			var ID=$(this).attr('id');
			$("#activities_"+ID).hide();
			$("#dob_"+ID).hide();
			$("#position_"+ID).hide();
			$("#bio_"+ID).hide();
			
			$("#first_input_"+ID).show();
			$("#last_input_"+ID).show();
			$("#relationship_input_"+ID).show();
			$("#bio_input_"+ID).show();
		}).change(function() {
			var ID=$(this).attr('id');
			var first=$("#first_input_"+ID).val();
			var last=$("#last_input_"+ID).val();
			var relationship=$("#relationship_input_"+ID).val();
			var bio=$("#bio_input_"+ID).val();
			var dataString = 'id='+ ID +'&firstname='+first+'&lastname='+last+'&relationship='+relationship+'&bio='+bio;
			$("#first_"+ID).html('<img src="load.gif" />');
	
			//this section makes sure the correct data is not-null and passed into ajax processing file
			if(first.length && last.length>0) {
				$.ajax({
				type: "POST",
				url: "ajax.php",
				data: dataString,
				cache: false,
				success: function(html) {	
					$("#first_"+ID).html(first);
					$("#last_"+ID).html(last);
					$("#relationship_"+ID).html(relationship);
					$("#bio_"+ID).html(bio);
				}
				});
			} else {
				alert('Enter something.');
			}
		}); //close of the click and ajax submit sections
	
	//THIS SECTION IS FOR WHEN THE EDITABLE BOX IS MOUSE RELEASED.
	$(".editbox").mouseup(function() {
		return false
	});

	$(document).mouseup(function(){
		$(".editbox").hide();
		$(".text").show();
	});
});

