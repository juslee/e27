/*
 * Copyright (c) 2010 Romain Ruetschi <romain.ruetschi@gmail.com>
 * 
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 * 
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
 * LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 * OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
 * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
(function($){$.fn.placeHoldize=(function(){var supportsPlaceholder=(function(elem){return!!(elem.placeholder==='')&&!!(elem.placeholder!==undefined);})(document.createElement('input'));function _placeHoldize(force){var $this=$(this);if(!force&&(supportsPlaceholder||!$this.attr('placeholder'))&&!$this.is('textarea')){return;}var placeHolder=$this.attr('placeholder');if($this.val().length<=0||$this.val()==placeHolder){$this.val('');$this.removeAttr('placeholder').addClass('placeholder-visible');$this.val(placeHolder);}else
{$this.removeClass('placeholder-visible').addClass('placeholder-hidden');}$this.addClass('placeholdized');$this.focus(function(){var $this=$(this);if($this.val()===placeHolder){$this.val('');$this.removeClass('placeholder-visible').addClass('placeholder-hidden');}});$this.blur(function(){var $this=$(this);if($this.val()===''){$this.val(placeHolder);$this.removeClass('placeholder-hidden').addClass('placeholder-visible');}else
{$this.removeClass('placeholder-visible').addClass('placeholder-hidden');}});}function _emptyFormOnSubmit($elements){var $forms=$elements.closest('form');$forms.submit(function(){var $this=$(this);if($this.data('placeHoldize.submitHandlerCalled')){return;}$this.find('.placeholder-visible').val('').data('placeHoldize.submitHandlerCalled',true);});return true;}return function(force){this.each(function(){_placeHoldize.call(this,force);});_emptyFormOnSubmit(this);return this;};})();})(jQuery);
