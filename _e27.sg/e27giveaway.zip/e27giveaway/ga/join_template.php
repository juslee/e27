<?php
include("../lib/dbcon.php");
if(isset($_POST['giveaway_name'])) 
{

$giveaway_name				=(filter_var($_POST['giveaway_name'],FILTER_SANITIZE_SPECIAL_CHARS));
$giveaway_description		=(filter_var($_POST['giveaway_description'],FILTER_SANITIZE_SPECIAL_CHARS));
$giveaway_benefits			=(filter_var($_POST['giveaway_benefits'],FILTER_SANITIZE_SPECIAL_CHARS));
$giveaway_prize_description	=(filter_var($_POST['giveaway_prize_description'],FILTER_SANITIZE_SPECIAL_CHARS));
$giveaway_question			=(filter_var($_POST['giveaway_question'],FILTER_SANITIZE_SPECIAL_CHARS));
$giveaway_start_date		=(filter_var($_POST['giveaway_start_date'],FILTER_SANITIZE_SPECIAL_CHARS));
$giveaway_end_date			=(filter_var($_POST['giveaway_end_date'],FILTER_SANITIZE_SPECIAL_CHARS));
$giveaway_legal				=(filter_var($_POST['giveaway_legal'],FILTER_SANITIZE_SPECIAL_CHARS));


//Start Config
$homepath = "e27giveaways/";

// End config

$dir = ($_POST['giveaway_name']);
$userDir1 = $homepath.str_replace( " "  , "_"  , $dir) ;

//create the new directory

$newDir = mkdir($userDir1, 0777);
$_SESSION["session_start"] = $newDir;

if($newDir==true)
{

$newDir = fopen("$userDir1/index.php","w");
//dir path and CMS insert sql query.
$path="http://e27giveaway.10dd.co/ga/$userDir1/index.php";
$sql = "INSERT INTO giveaway	(giveaway_id,giveaway_name,giveaway_description,giveaway_benefits,giveaway_prize_description,giveaway_question,giveaway_start_date,giveaway_end_date,giveaway_legal,giveaway_url) VALUES ('','$giveaway_name','$giveaway_description','$giveaway_benefits','$giveaway_prize_description','$giveaway_question','$giveaway_start_date','$giveaway_end_date','$giveaway_legal','$path')";
mysql_query($sql);

$giveaway_id=mysql_insert_id();
$sql_in=mysql_query("SELECT giveaway_name,giveaway_url,giveaway_id FROM giveaway where giveaway_id='$giveaway_id' order by giveaway_id desc");
$r=mysql_fetch_array($sql_in);
$path="$userDir1";
$_SESSION['varname'] = $path;
//template generating datawrite script. passing path and giveaway_id variables to the datawrite script.
$datawrite='

<?php 
include("../../../lib/dbcon.php"); 
session_start();
if(isset($_SESSION["userURL_email"]))
{
$user_email_mike=$_SESSION["userURL_email"];
}
else
{
$user_email_mike= "";
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns:og="http://ogp.me/ns#" xmlns:fb="https://www.facebook.com/2008/fbml">
<head>
<title></title>
<script type="text/javascript" src="http://code.jquery.com/jquery-1.6.3.min.js"></script>
<script type="text/javascript" src="../../../js/jquery.anythingslider.js"></script>
<script type="text/javascript" src="../../../js/jquery.countdown.js"></script>
<script type="text/javascript" src="../../../js/script.js"></script>
<script type="text/javascript" src="../../../js/jquery.ui.core.js"></script>
<script type="text/javascript" src="../../../js/jquery.ui.widget.js"></script>
<script type="text/javascript" src="../../../js/jquery.ui.accordion.js"></script>
<script type="text/javascript" src="../../../js/transition.js"></script>
<script type="text/javascript" src="../../../js/jquery.slidingtabs.pack.js"></script>
<script type="text/javascript" src="../../../js/cufon-yui.js" ></script>
<script type="text/javascript" src="../../../js/fonts/Myriad_Pro_700.font.js"></script>
<script type="text/javascript" src="../../../js/fonts/myriadreg_400.font.js"></script>
<script type="text/javascript">
$(document).ready(function() {
Cufon.replace("h1", { fontFamily: "myriadreg" });
Cufon.replace("h2", { fontFamily: "helvthin" });
Cufon.replace("h3", { fontFamily: "myriadreg" });
Cufon.replace("h4", { fontFamily: "myriadreg" });
Cufon.replace("h5", { fontFamily: "myriadreg" });
Cufon.replace("h6", { fontFamily: "helvthin" });
Cufon.replace("h7", { fontFamily: "myriadreg" });
Cufon.replace(".label", { fontFamily: "myriadreg" });
Cufon.replace("#question", { fontFamily: "myriadreg" });
});
</script>
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(["_setAccount", "UA-33436779-1"]);
  _gaq.push(["_trackPageview"]);

  (function() {
    var ga = document.createElement("script"); ga.type = "text/javascript"; ga.async = true;
    ga.src = ("https:" == document.location.protocol ? "https://ssl" : "http://www") + ".google-analytics.com/ga.js";
    var s = document.getElementsByTagName("script")[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
<script type="text/javascript">


$(function() {

		
	
$(".submit").click(function() {
	var x=document.forms["form1"]["userURL_email"].value;
	var atpos=x.indexOf("@");
	var dotpos=x.lastIndexOf(".");
	if (atpos<1 || dotpos<atpos+2 || dotpos+2>=x.length)
	  {
	  alert("Not a valid e-mail address");
	  
	  return false;
	  }
	
	

	var userURL_id 					= $("#userURL_id").val();
	var userURL_question 			= $("#userURL_question").val();
	var userURL_email				= $("#userURL_email").val();
	var userURL_old					= $("#userURL_old").val();
	var giveaway_id					= $("#giveaway_id").val();
	
	
	 var dataString = "&userURL_question="+ userURL_question+ "&userURL_email=" + userURL_email+ "&userURL_old=" + userURL_old+ "&giveaway_id=" + giveaway_id;
	 //alert(dataString);
		if (userURL_question == "" || userURL_question != "e27") {
            alert("Please select an answer for question #1.");
			
			
			
		} else {
			
		
			$(".step1").hide();
			$("#tab2").fadeIn(500);
			$("#tab1").fadeOut(100);
			$.ajax({
			type:"POST",
			url:"../../lib/ajax20.php",
			data: dataString,
			cache:false,
			success:function(html){
				$(".step2").show();
				$("#userURL_question").val("");
				$("#userURL_email").val("");
				$("#display").after(html);
				$("#img").show();
				$("#img").fadeOut(200);
				document.getElementById("").focus();
				//$("#flash").hide();
				document.getElementById("countdown").value="120";
			}
			});
	}return false;
});
});

$(document).ready(function() {
	$(".tab-content").hide();
	$("ul.tabs li:first").addClass("active").show();
	$(".tab-content:first").show();
	
	/* $("ul.tabs li").click(function() {
	    $("ul.tabs li").removeClass("active");
	    $(this).addClass("active");
	    $(".tab-content").hide();
	    var activeTab = $(this).find("a").attr("href");
	    $(activeTab).show();
	    return false;
	}); */
});

</script>
<script>
function toggle() {
	var ele = document.getElementById("toggleRules");
	var text = document.getElementById("displayRules");
	if(ele.style.display == "block") {
    		ele.style.display = "none";
		text.innerHTML = "Read official rules.";
  	}
	else {
		ele.style.display = "block";
		text.innerHTML = "Hide the rules.";
	}
}




</script>


<script src="../../../js/jquery.validate.js" type="text/javascript"></script>

	



<script type="text/javascript">

    $(document).ready(function() {

    $.validator.addMethod("userURL_email", function(value, element) {  
    return this.optional(element) || /^[a-zA-Z0-9._-]+@[a-zA-Z0-9-]+\.[a-zA-Z.]{2,5}$/i.test(value);  
    }, "Please enter a valid emaill address.");
     
	 

    
        // Validate signup form
        $("#signup").validate({
                rules: {
                        userURL_email: "required email",
						

                },
				

        });

    });
</script>
<style>
#slider { width: 355px; height: 410px; }
@import "jquery.countdown.css";
#defaultCountdown { width: 300px; height: 91px; color: white;font-family: Helvetica; font-size: 36px; padding-top: 15px;font-stretch: semi-expanded;}

/*

Important Notes

1. Avoid using Percentages or Fluid Widths, declare all pixel dimensions explicitly. 
2. Alwas use one-line CSS shorthand
3. Make sure all styles are in ONE stylesheet.
4. ORGANISE CSS INTO REVELANT SECTIONS
5. Write CSS in the order it appears in HTML
6. Make sure to include !important for older browsers
7. Ensure cross-browser compatibility
8. Make sure all CSS braces are aligned as shown in the Reset block

*/

/*====================*/
/*=== Reset Styles ===*/
/*====================*/

html, body, input, div												{margin:0;padding:0;border:0;outline:0;font-weight:inherit;font-style:inherit;font-size:100%;font-family:inherit;vertical-align:baseline;text-align: center;text-align: left;}

table 																{border-collapse:separate;border-spacing:0;font-size: 10pt;margin: 0 auto;}
caption, th, td 													{text-align:left;font-weight:normal;}
blockquote:before, blockquote:after,q:before, q:after 				{content:"";}
blockquote, q 														{quotes:"" "";}
/* HTML5 tags */
header, section, footer,aside, nav, article, figure 				{display: block;}
ul, li																{list-style: none;}
.clear																{clear: both;}
.fleft																{float: left;}
.fright																{float: right;}
div																	{margin: 0; padding: 0;}

p																	{font-family: Arial; font-size: 12px; font-weight: normal; color: #616161}
h1																	{margin: 0; padding: 0; line-height: 30px; font-size: 26px; color: #616161}
h2																	{margin: 0; padding: 0; line-height: 85px; font-size: 80px; color: #616161}
.label																{font-size: 15px; font-family: Verdana; font-weight: bold; color: #979da8;}

	
#wrapper															{width:100%; height: 100%; background: url(../../../img/bg_mainfront.png) top left;}
#topnav																{width:100%; background: black; height: 54px;}
#container															{width:1000px; margin: 0 auto; min-height: 800px; background: white;}
#header																{border-bottom: 1px solid #ebebeb;}
.logo																{margin: 10px;}
#slider_container													{min-height: 400px; background: #cee5f3; position: relative;}
#slider_info														{width: 300px; height: 350px; position: absolute; top: 25px; right: 35px; border:1px dashed #fff; padding: 0; margin: 0;}
#content_container													{width:100%; margin: 0; padding: 0}
#left_content														{float: left; width: 400px; margin: 35px 20px 0 35px; min-height: 150px; /* border: 1px dashed #ebebeb; */}
#right_content														{float: left; width: 520px; margin: 20px 16px 20px 0px; min-height: 150px;/* border: 1px dashed #ebebeb; */ border-left: 1px dashed #ebebeb}
#submenu															{width:100%; height: 60px; margin:0px 0 10px 0}
.class																{min-height: 100px;width: 500px; background: #ebebeb}
#signup1															{background: url(../../../img/bg_step1.png) no-repeat top left; width: 240px; height: 260px; float: right;position: relative;}
#signup2															{background: url(../../../img/bg_sharingbuttons.png) no-repeat top left; width: 240px; height: 425px; float: right;position: relative;}

ul#form_step1														{list-style: none;}
ul#form_step1 li													{position: relative; height: 40px; margin: 0 0px 20px -29px; width:210px;}

.label_tab															{background: url(../../../img/bg_whitelabelhover.png) no-repeat top left; width: 245px; height: 40px; position: relative; left: -245px; top: 0; line-height: 30px; padding: 3px 0 0 25px;}

#footer																{min-height: 100px; width: 100%; border-top: 5px solid #ebebeb;}


a#submit_answer														{background: url(../../../img/button_submitanswer.png) no-repeat top left; width:240px; height: 42px; text-indent: -9999px; display: block; position: absolute; bottom: 15px; left: 0;}
a#submit_answer:hover												{background-position: 0 -42px;}
a#submit_answer:active												{background-position: 0 -84px;}

ul.tabs																{list-style: none; position: relative; float: right; margin: 15px 5px 0 0;}
ul.tabs li 															{display: inline;}
ul.tabs li a 														{display: block; float: left; height: 39px;background-image: url(../../../img/bg_step12.png); text-indent: -9999px;}
ul.tabs li a.step1 													{width: 165px; background-position: 0 0;}
ul.tabs li a.step2 													{width: 165px; background-position: 165px 0;}
/* ul.tabs li a.step1:hover, */ ul.tabs li a.step1:active			{width: 165px; background-position: 0 -78px;}
/* ul.tabs li a.step2:hover, */ ul.tabs li a.step2:active			{width: 165px; background-position: 165px -78px;}

#question															{width:150px; margin:0 auto; text-align: left; font-family:Arial; font-weight: 400; font-size: 14px; margin-top: -30px; color: #979da8; position:absolute; top:40px; left:4px;}	

#instructions														{width:470px; background: url(../../../img/bg_howitworks.png) no-repeat top left; height: 200px;padding: 0; float: right;margin: 15px 3px 20px 0;}
#instructions_info													{width:250px; float: left; margin: 15px 0 0 25px;}
#instructions_views													{width:100px; float: right; margin: 15px 15px 0 0; text-align: center;}

#userURL_email														{margin:-22pt 0px 0px 15px; position:absolute;font-family: Arial; font-size: 12px; font-weight: normal; color: #616161;}	
#emailURL															{position:relative; bottom:-23px;right:-10px; width:250px;}
#userURL_question													{position:absolute; left:5px; bottom:-50px;}

.cssmenu					   										{margin:-55px 0px 10px -130px;padding:0;list-style-type:none;width:auto;position:absolute;
																		display:block;height:36px;font-size:12px;font-weight:bold;text-transform:uppercase;
																		background:transparent url("../../../img/.jpg") repeat-x top left;font-family:Arial;border-bottom:1px solid #000000;border-top:1px solid #000000;}
.cssmenu li															{display:block;float:left;margin:0;padding:0;}
.cssmenu li a														{display:block;float:left;color:#999999;text-decoration:none;font-weight:bold;
																		padding:12px 20px 0 20px;height:24px;}
.cssmenu li a:hover													{color:#FFFFFF;background:transparent url("../../../img/over.jpg") no-repeat top right;	}
.selectbox															{width:210px;}															
</style>
</head>


<body data-twttr-rendered="true">
   <div id="wrapper">
   		
   		<div id="topnav">
			
		</div>
   		<div id="container">
		<div class="cssmenu">
				<ul style="margin:0px 0px 0px 90px">
				   <li class="active "><a href="#"><span>HOME</span></a></li>
				   <li><a href="#"><span>ECHELON 2012</span></a></li>
				   <li><a href="#"><span>STARTUP LIST</span></a></li>
				   <li><a href="#"><span>Contact</span></a></li>
				   <li><a href="#" id="search"><span>Search</span></a></li>
				</ul>
			</div>
		<?php
						$sql = mysql_query("SELECT * FROM giveaway where giveaway_id='.$giveaway_id.' ");
						
						while($row=mysql_fetch_array($sql))
						{
							$giveaway_id					=$row["giveaway_id"];
							$giveaway_name					=$row["giveaway_name"];
							$giveaway_description			=$row["giveaway_description"];
							$giveaway_additional_info		=$row["giveaway_additional_info"];
							$giveaway_benefits				=$row["giveaway_benefits"];
							$giveaway_prize_description		=$row["giveaway_prize_description"];
							$giveaway_question			    =$row["giveaway_question"];
							$giveaway_start_date			=$row["giveaway_start_date"];
							$giveaway_end_date				=$row["giveaway_end_date"];
							$giveaway_legal					=$row["giveaway_legal"];
							$giveaway_email					=$row["giveaway_email"];
							
						?>	
						<?php	} 
						?>
   			<div id="header">
   				<a class="fleft logo" href=""><img src="../../../img/logo_e27_main.png"></a>
   				<div class="clear"></div>
   			</div>
   			<div id="slider_container">
   				<div id="slider_info">
   					<h1><?php echo $giveaway_name; ?></h1>
					<p><?php echo $giveaway_description; ?></p>
   				</div>
   			</div>
   			
   			<!-- =========================== MAIN CONTENT ============================== -->
   			
   			<div id="content_container">
   				<div id="left_content">
   					<h1>Giveaway Details</h1>
					
						
						
						
						<p class="disclaimer">Enter sweepstakes and receive exclusive offers from e27giveaway. Unsubscribe anytime.<br> with the contest. <a id="displayRules" href="javascript:toggle();" >Read official rules.</a></p>
						<p class=""><br><span id="<?php echo $giveaway_id; ?>" class="text"><h1>Ending Date:<?php echo $giveaway_end_date; ?></h1></span></p>
						 
						
   				</div>
   				<div id="right_content">
					
   					<div id="submenu">
   						<div class="fleft">
   							<h1 style="margin:15px 0 0 85px;">Steps</h1>
   						</div>
   						<ul class="tabs">
						   <li><img  class="step1" style="margin-top:-70px;" src="../../../img/step1.png"/></li>
						   <li><img  class="step2" style="display:none;margin-top:-70px;" src="../../../img/step2.png"/></li>
						</ul>
   					</div>
   					<div class="clear"></div>
   					<div class="tab-container">
					    <div id="tab1" class="tab-content">
					        <div id="fleft"></div>
	   						<div id="signup1">
	   							<ul id="form_step1">
	   								<li>
	   									<div class="label_tab label">Please insert your email:</div>
	   									<!-- form email input goes here -->
								<form  enctype="multipart/form-data" method="post"  name="form1"  id="signup" action=""  onsubmit="return validateForm();">
											<input id="userURL_email" type="text" name="userURL_email"  value=""/>
											<input id="userURL_old" type="hidden" name="userURL_old" value="'.($path).'"/>
											<input id="giveaway_id" type="hidden" name="giveaway_id" value="'.($giveaway_id).'"/>
												
									</li>
										<li style="margin-top:15px;">
											<div class="label_tab label">Answer the question:</div>
											<div id="question"><?php echo $giveaway_question; ?></div>
											<!-- form question input goes here -->
											
												<select id="userURL_question" name="userURL_question">
												  <option value="">Select your answer</option>
												  <option value="e27">e27, duh!</option>
												  <option value="president">The Vice President, I think?</option>
												  <option value="Spiderman">Spiderman, duh nuh nuh nuh...</option>
												</select>
										</li>
											
	   							</ul>
										<a href="" type="submit" id="submit_answer" value="Submit" class="submit">Submit Answer</a>
										
										
										<span class="success" style="display:none">uploaded Successfully</span>
								</form>
	   						</div>
	   						<div class="clear"></div>
					    </div>
						<img src="../../../img/8-0.gif" id="img" style="display:none;margin:0px 0px 0px 150px;"/>	
					    <div id="display"></div>
					</div>
   				</div> <!-- close right content -->
   				<div class="clear"></div>
   			</div> <!-- close content_container -->
   			<div id="footer">
				<div class="rules" id="toggleRules" style="display:none;margin: 35px 20px 0 35px;">
					<h1 class="headline">Giveaway Rules</h1>
					<ul>
					 <li>
					  <p style="margin: 0px 0px 0px -40px;">
						<?php echo $giveaway_legal; ?>
					  </p>
						<div class="clear"></div>
					 </li>
					</ul>
				</div>
			</div>
   		</div> <!-- close container -->
   	
   		
   </div><!-- End Wrapper -->

</body>
</html>


';

fwrite($newDir,$datawrite);

}
}
?>	
	

<!--passing buttons to javascript ajax.-->

<li class='record'><?php
 echo $r['giveaway_name'];?>
<a  href="<?php echo $r['giveaway_url'];?>" class='linkbutton'><?php echo $r['giveaway_url'];?></a>
<a href='#' id="<?php echo $r['giveaway_id'];?>" class='delbutton'></a>
<a href='#' id="<?php echo $r['giveaway_id'];?>" class='edit'></a>
<a href='#' id="<?php echo $r['giveaway_id'];?>" class='edit2'></a>
</li>





