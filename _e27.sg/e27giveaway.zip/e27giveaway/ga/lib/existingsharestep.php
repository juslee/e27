<?php
	session_start();
	
	$sql = "SELECT userURL_address,userURL_visitors FROM userURL WHERE userURL_email = '".$userURL_email."' and giveaway_id ='".$giveaway_id."' ORDER BY userURL_email DESC LIMIT 1 ";
	$res = mysql_query($sql) or die(mysql_error());
	$last=mysql_num_rows($res);
	if($last==0)
	die("No Featured Items!");
	$i=0;
	while($row = mysql_fetch_array($res))
	{
		$userURL_address= $row["userURL_address"];
		$userURL_visitors=$row["userURL_visitors"];
		$i++;
	 
	?> <?php
	} 
	$_SESSION['userURL_email']= $userURL_email;
//end of PHP processing	
//beginning of HTML printing 		
?>	



<div id="tab2" class="tab-content">
	<div id="instructions">
		<div id="instructions_info">
			<h1>How it works</h1>
			<p>To win, you need to collect the most amount of page views on your unique URL provided below.<br>Click the buttons below to share on Facebook, Twitter and others!
			<input id="emailURL"  rows="1" onclick="highlight(this);" value="<?php echo $userURL_address;?>"/>
			</p>
		</div>
		<div id="instructions_views">
			<h1 style="font-size:20px;">Your Views</h1>
			<h2><?php echo $userURL_visitors;?></h2>
			<!--<p>AJAX called views for each userURL when filled on the left</p>-->
		</div>
		<div class="clear"></div>
	</div>
	<div id="signup2">
		<ul id="form_step1">
			<li>
				<div class="label_tab label" >Share on Facebook:</div>
				<!--button goes here -->
				<div style="position :absolute; top:10px; left:0px;">
				<a name="fb_share" share_url="<?php echo $userURL_address;?>" type='button_count'></a> 
				<script src="http://static.ak.fbcdn.net/connect.php/js/FB.Share" type="text/javascript"></script></div>
			</li>
			<!--<li style="margin-top:15px;">
				<div class="label_tab label">Share on LinkedIn:</div>
				 buttont goes here <div style="position :absolute; top:10px; left:0px;">
				<script src="//platform.linkedin.com/in.js" type="text/javascript"></script>
				<script type="IN/Share" data-url="<?php// echo $userURL_address;?>" data-counter="right"></script></div>
			</li>-->
			<li style="margin-top:15px;">
				<div class="label_tab label">Share on Twitter:</div>
				<!-- button goes here --><div style="position :absolute; top:10px; left:0px; ">
					<a href="https://twitter.com/share" class="twitter-share-button" 
				data-url= "<?php echo $userURL_address;?>" data-via="e27" data-lang="en" data-count="horizontal">Tweet</a>

					<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="//platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script></div>
			</li>
			<li style="margin-top:15px;">
			<div class="label_tab label">Share on Google+:</div><div style="position :absolute; top:10px; left:0px;">
			<!-- Place this tag where you want the share button to render. -->
			<div class="g-plus" data-action="share" data-href="<?php echo $userURL_address;?>"></div>

			<!-- Place this tag after the last share tag. -->
			<script type="text/javascript">
			  (function() {
				var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
				po.src = 'https://apis.google.com/js/plusone.js';
				var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
			  })();
			</script></div>
			</li>
			<li style="margin-top:15px;">
			<div class="label_tab label">Share on StumbleUpon:</div><div style="position :absolute; top:10px; left:0px;">
			<!-- Place this tag where you want the su badge to render -->
			<su:badge layout="1" location="<?php echo $userURL_address;?>"></su:badge>

			<!-- Place this snippet wherever appropriate -->
			<script type="text/javascript">
			  (function() {
				var li = document.createElement('script'); li.type = 'text/javascript'; li.async = true;
				li.src = 'https://platform.stumbleupon.com/1/widgets.js';
				var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(li, s);
			  })();
			</script></div>
			</li>
		</ul>
	</div>	   					
	<div class="clear"></div>
</div>	  
<div class="clear"></div>        	  
	
<!--need for the font style in the share buttons.-->
<script type="text/javascript" src="../../js/cufon-yui.js" ></script>
<script type="text/javascript" src="../../js/fonts/Myriad_Pro_700.font.js"></script>
<script type="text/javascript" src="../../js/fonts/myriadreg_400.font.js"></script>
<script type="text/javascript">
$(document).ready(function() {
Cufon.replace("h1", { fontFamily: "myriadreg" });
Cufon.replace("h2", { fontFamily: "helvthin" });
Cufon.replace("h3", { fontFamily: "myriadreg" });
Cufon.replace("h4", { fontFamily: "myriadreg" });
Cufon.replace("h5", { fontFamily: "myriadreg" });
Cufon.replace("h6", { fontFamily: "helvthin" });
Cufon.replace("h7", { fontFamily: "myriadreg" });
Cufon.replace(".label", { fontFamily: "myriadreg" });
Cufon.replace("#question", { fontFamily: "myriadreg" });
});
</script>	