<?php		
session_start();

function str_rand($length = 11, $seeds = 'alphanum')
{
	// ----------- > This function creates a random string to be used for each user when they sign up.
	// Possible seeds
	$seedings['alpha'] = 'abcdefghijklmnopqrstuvwqyz';
	$seedings['numeric'] = '0123456789';
	$seedings['alphanum'] = 'abcdefghijklmnopqrstuvwqyz0123456789';
	$seedings['hexidec'] = '0123456789abcdef';
	
	// Choose seed
	if (isset($seedings[$seeds])){
		$seeds = $seedings[$seeds];
	}
	
	// Seed generator
	list($usec, $sec) = explode(' ', microtime());
	$seed = (float) $sec + ((float) $usec * 100000);
	mt_srand($seed);
	
	// Generate Random string for each user when they sign up
	$str = '';
	$seeds_count = strlen($seeds);
	
	for ($i = 0; $length > $i; $i++){
		$str .= $seeds{mt_rand(0, $seeds_count - 1)};
	}
	return $str;
}

//new directory variable preparation.
$homepath = "../$userURL_old/";
$str=str_rand();
$userDir = $homepath.str_replace( " "  , "_"  , $str) ;

//create the new directory
if($userDir==true) {
	$userDir = fopen("$homepath/$str.php","w");
	$path="http://e27giveaway.10dd.co/ga/$userURL_old/$str.php";
	
	$sql = "INSERT INTO userURL (userURL_id,giveaway_id,userURL_question,userURL_email,userURL_address,userURL_old) VALUE ('','$giveaway_id','$userURL_question','$userURL_email','$path','$userURL_old')";
	mysql_query($sql)or die(mysql_error);
	$userURL_id=mysql_insert_id();
	session_start();
	
}else{
	echo "not success";
}
//datawrite for random php file. passing userURL_id into the db through ajax.
//cookie creation…not needed? 
$datawrite='
<!DOCTYPE html>
<html>
<head>
<script type="text/javascript" src="http://code.jquery.com/jquery-1.6.3.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
	var userURL_id= $("#userURL_id").val();
	var dataString = "&userURL_id=" + userURL_id;
		//alert("Continue to the step 1.");
		if (userURL_id == "" ) {
          //  alert("alert");
			
			
			
		} else {
			
			$.ajax({
			type:"POST",
			url:"../../Visitor1/theCollector.php",
			data: dataString,
			cache:false,
			success:function(html){
				
				
			}
			});
	}return false;
});
</script>
</head>
<body>
		<form  enctype="multipart/form-data" method="post"  name="form1"  action="" >
			<input id="userURL_id" type="hidden" name="userURL_id" value="'.($userURL_id).'"/>
		</form>
</body>
</html>

 	<?php ob_start();
		
		include("../../Visitor1/theCollector.php");

		//First we need to check if the user has visited before
		//Let"s use "visittime" as the name for our cookie

		if(isset($_COOKIE["visittime"]))
		{
		  echo "Welcome back!<br>";
		  
		  //Calculate how long is since the users last visit
		  //We can do this simply by subtracting the last visit
		  //time from the current time
		  $timeElapsed = time() - $_COOKIE["visittime"];

		  echo "It has been " . $timeElapsed . " seconds since your last visit.";
		}
		else
		{
		  //echo "I see you are new here";
		}

		//Set the current time as a cookie and make it expire much later.
		$nextYear = time() + (60 * 60 * 24 * 365);
		setcookie("visittime", time(), $nextYear);
		 
			error_reporting(E_ALL);
			echo "<meta http-equiv=\"refresh\" content=\"0;url=index.php\" />";
			exit;
			ob_end_flush();			
	?>';

fwrite($userDir,$datawrite);
//need for sharing buttons and visitor views.
$sql = "SELECT userURL_address,userURL_visitors FROM userURL WHERE userURL_email = '".$userURL_email."' and giveaway_id ='".$giveaway_id."' ORDER BY userURL_id DESC LIMIT 1 ";
$res = mysql_query($sql) or die(mysql_error());
$last=mysql_num_rows($res);
if($last==0)
die("No Featured Items!");
$i=0;
while($row = mysql_fetch_array($res)) {
	$userURL_address= $row["userURL_address"];
	$userURL_visitors=$row["userURL_visitors"];
	$i++;
}

$_SESSION['userURL_email']= $userURL_email;
//end of PHP processing
//beginning of HTML printing 
?>				
				
				
<div id="tab2" class="tab-content">
	<div id="instructions">
		<div id="instructions_info">
			<h1>How it works</h1>
			<p>To win, you need to collect the most amount of page views on your unique URL provided below.<br>Click the buttons below to share on Facebook, Twitter and others!
			<input id="emailURL"  rows="1" onclick="highlight(this);" value="<?php echo $userURL_address;?>"/>
			</p>
		</div>
		<div id="instructions_views">
			<h1 style="font-size:20px;">Your Views</h1>
			<h2><?php echo $userURL_visitors;?></h2>
			<!--<p>AJAX called views for each userURL when filled on the left</p>-->
		</div>
		<div class="clear"></div>
	</div>
			
	<div id="signup2">
		<ul id="form_step1">
			<li>
				<div class="label_tab label">Share on Facebook:</div><div style="position :absolute; top:10px; left:0px;">
				<!--button goes here -->
				<a name="fb_share" share_url="<?php echo $userURL_address;?>" ></a> 
				<script src="http://static.ak.fbcdn.net/connect.php/js/FB.Share"  type="text/javascript"></script></div>
			</li>
			<!--<li style="margin-top:15px;">
				<div class="label_tab label">Share on LinkedIn:</div><div style="position :absolute; top:10px; left:0px;">
				<!-- buttont goes here 
				<script src="//platform.linkedin.com/in.js" type="text/javascript"></script>
				<script type="IN/Share" data-url="<?php// echo $userURL_address;?>" data-counter="right"></script></div>
			</li>-->
			<li style="margin-top:15px;">
				<div class="label_tab label">Share on Twitter:</div><div style="position :absolute; top:10px; left:0px;">
				<!-- button goes here -->
					<a href="https://twitter.com/share" class="twitter-share-button" 
				data-url= "<?php echo $userURL_address;?>" data-via="your_screen_name" data-lang="en">Tweet</a>

					<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="//platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script></div>
			</li>
				<li style="margin-top:15px;">
				<div class="label_tab label">Share on Google+:</div><div style="position :absolute; top:10px; left:0px;">
				<!-- Place this tag where you want the share button to render. -->
				<div class="g-plus" data-action="share" data-href="<?php echo $userURL_address;?>"></div>

				<!-- Place this tag after the last share tag. -->
				<script type="text/javascript">
				  (function() {
					var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
					po.src = 'https://apis.google.com/js/plusone.js';
					var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
				  })();
				</script></div>
			</li>
			<li style="margin-top:15px;">
				<div class="label_tab label">Share on StumbleUpon:</div><div style="position :absolute; top:10px; left:0px;">
				<!-- Place this tag where you want the su badge to render -->
				<su:badge layout="1" location="<?php echo $userURL_address;?>"></su:badge>
				<!-- Place this snippet wherever appropriate -->
				<script type="text/javascript">
				  (function() {
					var li = document.createElement('script'); li.type = 'text/javascript'; li.async = true;
					li.src = 'https://platform.stumbleupon.com/1/widgets.js';
					var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(li, s);
				  })();
				</script></div>
			</li>
		</ul>
	</div>	   					
	<div class="clear"></div>
</div>	  
<div class="clear"></div>

<!--Need for share buttons li fonts. -->
<script type="text/javascript" src="../../js/cufon-yui.js" ></script>
<script type="text/javascript" src="../../js/fonts/Myriad_Pro_700.font.js"></script>
<script type="text/javascript" src="../../js/fonts/myriadreg_400.font.js"></script>
<script type="text/javascript">
$(document).ready(function() {
Cufon.replace("h1", { fontFamily: "myriadreg" });
Cufon.replace("h2", { fontFamily: "helvthin" });
Cufon.replace("h3", { fontFamily: "myriadreg" });
Cufon.replace("h4", { fontFamily: "myriadreg" });
Cufon.replace("h5", { fontFamily: "myriadreg" });
Cufon.replace("h6", { fontFamily: "helvthin" });
Cufon.replace("h7", { fontFamily: "myriadreg" });
Cufon.replace(".label", { fontFamily: "myriadreg" });
Cufon.replace("#question", { fontFamily: "myriadreg" });
});
</script>	
