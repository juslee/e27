<?php 
// Make a MySQL Connection
include('dbcon.php');

if($_POST)
{
			
$giveaway_id				=$_POST['giveaway_id'];
$userURL_question			=$_POST['userURL_question'];
$userURL_email				=$_POST['userURL_email'];
$userURL_old				=$_POST['userURL_old'];

if(!$userURL_email || !$userURL_question){
		//if not display an error message
		echo "<center>You need to fill in a <b>userURL_email</b> and a <b>userURL_question</b>!</center>";
	}else{
		//if the were continue checking
		
		//select all rows from the table where the userURL_email matches the one entered by the user
		$res = mysql_query("SELECT * FROM `userURL` WHERE `userURL_email` = '".$userURL_email."' and giveaway_id ='".$giveaway_id."'");
		$row = mysql_num_rows($res);
		
		//check if there was not a match
		if($row == 0){
			//if not display an error message
			include("newsharestep.php");
			//echo "1"; 
		}else{
			include("existingsharestep.php");
			//echo "2";
		}
	}
}	
?>