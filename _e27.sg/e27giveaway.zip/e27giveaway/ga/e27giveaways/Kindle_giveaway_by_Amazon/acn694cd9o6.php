
<?php include("../../lib/dbcon.php"); ob_start();?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns:og="http://ogp.me/ns#" xmlns:fb="https://www.facebook.com/2008/fbml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta property="og:site_name" content="giveaway">
<meta property="og:email" content="support@10dd.co">
<title></title>
<link rel="stylesheet" type="text/css" href="../../styles/main.css" />
<link rel="stylesheet" type="text/css" href="../../styles/styles.css" />

<script src="../../js/hubclient.js" async="" type="text/javascript" id="LR1"></script>
<script src="../../js/ga.js" async="" type="text/javascript"></script>
<script src="../../js/widgets.js" async="" type="text/javascript"></script>









</head>
  <!--[if lt IE 7 ]> <body class="ie6"> <![endif]-->
  <!--[if IE 7 ]>    <body class="ie7"> <![endif]-->
  <!--[if IE 8 ]>    <body class="ie8"> <![endif]-->
  <!--[if IE 9 ]>    <body class="ie9"> <![endif]-->
  <!--[if (gt IE 9)|!(IE)]><!--> 
<body data-twttr-rendered="true">



   <!-- Begin Wrapper -->
   
   
         <!-- Begin Header -->
         
		 
		<?php
		//First we need to check if the user has visited before
		//Let"s use "visittime" as the name for our cookie

		if(isset($_COOKIE["visittime"]))
		{
		  echo "Welcome back!<br>";
		  
		  //Calculate how long is since the users last visit
		  //We can do this simply by subtracting the last visit
		  //time from the current time
		  $timeElapsed = time() - $_COOKIE["visittime"];

		  echo "It has been " . $timeElapsed . " seconds since your last visit.";
		}
		else
		{
		  echo "I see you are new here";
		}

		//Set the current time as a cookie and make it expire much later.
		$nextYear = time() + (60 * 60 * 24 * 365);
		setcookie("visittime", time(), $nextYear);
		?>	 
			   
		
		 <!-- End Header -->
		 
		 <!-- Begin Left Column -->
		 
		  
		 
		 
		 
		 
		
		 <!-- End Left Column -->
		 
		 <!-- Begin Right Column -->

		 
		
		 

		
		 <!-- End Right Column -->
		 
		 <!-- Begin Footer -->
		 
		 
		 
		 <?php include("../../Visitor1/theCollector.php");
		 
		 
		 
		 
		 
		 
		 
		 
		
			ob_clean();
			error_reporting(E_ALL);
			echo "<META HTTP-EQUIV="Refresh" Content="0; URL=index.php">";
			exit;
			ob_flush();			
		?>	
	     
		 <!-- End Footer -->
		 
   
   <!-- End Wrapper -->
				
  
</body>
</html>


