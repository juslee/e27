
<?php include("../../lib/dbcon.php"); ?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns:og="http://ogp.me/ns#" xmlns:fb="https://www.facebook.com/2008/fbml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta property="og:site_name" content="giveaway">
<meta property="og:email" content="support@10dd.co">
<title></title>
<link rel="stylesheet" type="text/css" href="../../styles/main.css" />
<link rel="stylesheet" type="text/css" href="../../styles/styles.css" />
<link rel="stylesheet" href="../../styles/anythingslider.css">
<script type="text/javascript" src="../../js/jquery-1.4.4.js">


</script>

<link rel="stylesheet" href="../../styles/jquery.countdown.css" />
<style>
	#slider { width: 355px; height: 410px; }
	
</style>
<?php include("../../lib/scripts1.php");?>	


<!-- jQuery --> 

<script>
$(function() {

	$(".submit").click(function() {


		var url_giveaways_id 					= $("#url_giveaways_id").val();
		var url_giveaways_question 				= $("#url_giveaways_question").val();
		var url_giveaways_email					= $("#url_giveaways_email").val();
		var url_old								= $("#url_old").val();

		
		
		 var dataString = "&url_giveaways_question="+ url_giveaways_question+ "&url_giveaways_email=" + url_giveaways_email+ "&url_old=" + url_old;
		 alert(dataString);
			if(url_giveaways_email=="") {
				alert("please Enter a valid email");
			} else {
				
			
				
				$("#step2").fadeIn(500);
				$("#step1").fadeOut(100);
				$.ajax({
				type:"POST",
				url:"../../lib/ajax2.php",
				data: dataString,
				cache:false,
				success:function(html){
					
					$("#url_giveaways_question").val("");
					$("#url_giveaways_email").val("");
				 
					$("#display").after(html);
					document.getElementById("").focus();
					//$("#flash").hide();
					document.getElementById("countdown").value="120";
				}
				});
		}return false;
	});
});
		
<!--fadeIn and fadeOut the form div.-->
$(document).ready(function(){
	  $(".btn1").click(function(){
	  $("#step1").fadeIn();
	  $("#step2").fadeOut();
	  $("#step3").fadeOut();
	  
	 
	  });
	  $(".btn2").click(function(){
	  $("#step2").fadeIn();
	  $("#step1").fadeOut();
	  $("#step3").fadeOut();
	  });
	  $(".btn3").click(function(){
	  $("#step3").fadeIn();
	  $("#step1").fadeOut();
	  $("#step2").fadeOut();
	});
});



// DOM Ready
		
		// DOM Ready
		$(function(){
			$("#slider").anythingSlider();
		});
	






$(function () {
	

	$("#defaultCountdown").countdown({ 
    until: new Date(2012, 8 - 1, 8)}); 
	$("#defaultCountdown").countdown({ 
    until: $.countdown.UTCDate(+10, 2012, 1 - 1, 26)}); 
	$("#defaultCountdown").countdown({until: +6000000}); 
	$("#defaultCountdown").countdown({until: "+1m -1d"});
	$("#year").text(austDay.getFullYear());
});


	//$(function() {
	//	$( "#accordion" ).accordion();
	//});

	
</script>


<!--<script>function fbs_click() {u=location.href;t=document.title;
	  window.open("http://www.facebook.com/sharer.php?u="+encodeURIComponent(u)+"&t="+encodeURIComponent(t),"sharer","toolbar=0,status=0,width=626,height=436");
	  return false;}
		
		!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="//platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");
	  
	  
</script>-->
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, "script", "facebook-jssdk"));</script>




</head>
  <!--[if lt IE 7 ]> <body class="ie6"> <![endif]-->
  <!--[if IE 7 ]>    <body class="ie7"> <![endif]-->
  <!--[if IE 8 ]>    <body class="ie8"> <![endif]-->
  <!--[if IE 9 ]>    <body class="ie9"> <![endif]-->
  <!--[if (gt IE 9)|!(IE)]><!--> 
<body data-twttr-rendered="true">
<!--<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, "script", "facebook-jssdk"));</script>-->

   <!-- Begin Wrapper -->
   <div id="wrapper">
   
         <!-- Begin Header -->
		<div class="cssmenu">
			<ul style="margin:0px 0px 0px 180px">
			   <li class="active "><a href="#"><span>HOME</span></a></li>
			   <li><a href="#"><span>ECHELON 2012</span></a></li>
			   <li><a href="#"><span>STARTUP LIST</span></a></li>
			   <li><a href="#"><span>Contact</span></a></li>
			   <li><a href="#" id="search"><span>Search</span></a></li>
			</ul>
		</div>
			<div id="top_page">
				<div id="top_logo"><a href="http://10DD.com/">
						<img src="../../img/logo_e27.png" alt="Macupdate Bundle" border="0" ></a>
				</div>
				<div id="top_nav"> 						<div id="soldtop">Sold
						</div>						<a href="http://10DD.com/bundleaffiliates" class="affiliatesbtn" id="affiliates">Affiliates</a>
						<a href="#" class="receiptsbtn" id="receipts">Receipts</a>
						<a href="#" class="helpbtn" id="help">Help</a>
						<a href="#" class="discussbtn" id="discuss">Discuss</a>
				</div>
				<div class="break">
				</div>
				
				<div id="top_page_bottom">
						<div id="topleft">
								<div id="video_a"> <a href="http://www.youtube.com/embed/pdv0A5J0vy0" rel="lightbox[social]" class="videobtn" id="video_tour" title="MacUpdate June Bundle">Take a Video Tour</a>
										<div id="counter2"> 
										<div class="clear"></div>
											<div id="defaultCountdown"></div>
												
												
										</div>
								</div>
						</div>
						<div id="topright">
								
						
							<img src="../../img/11_mac_apps_one_bundle.png" alt="10 Mac Apps One Bundle" height="35" width="355" style="margin:0px; posistion:relative;">
							<ul style="list-style: none;" id="slider">

								<li style=" background-color:white;">TEST</li>

								<li><img src="../../img/slide-.jpg" alt=""></li>

								<li><img src="../../img/slide-civil-2.jpg" alt=""></li>

								<li><img src="../../img/slide-env-2.jpg" alt=""></li>

							</ul>						
																
														
						</div>
				</div>
			
			
	<!-- end top_page -->
		 	 
			   
		 
		 <!-- End Header -->
		 
		 <!-- Begin Left Column -->
		 <div id="leftcolumn">
		  
		 <h2>Details</h2>
		 
		 <?php
				$sql = mysql_query("SELECT * FROM giveaway order by giveaway_id desc LIMIT 1");
				
				while($row=mysql_fetch_array($sql))
				{
					$giveaway_id					=$row["giveaway_id"];
					$giveaway_name					=$row["giveaway_name"];
					$giveaway_description			=$row["giveaway_description"];
					$giveaway_additional_info		=$row["giveaway_additional_info"];
					$giveaway_benefits				=$row["giveaway_benefits"];
					$giveaway_prize_description		=$row["giveaway_prize_description"];
					$giveaway_question			    =$row["giveaway_question"];
					$giveaway_start_date			=$row["giveaway_start_date"];
					$giveaway_end_date				=$row["giveaway_end_date"];
					$giveaway_legal					=$row["giveaway_legal"];
					$giveaway_email					=$row["giveaway_email"];
					
	 			?>	
		 <br/>
		 <div class="clear"></div>

		 
		 
		 <p class="disclaimer">Enter sweepstakes and receive exclusive offers from e27giveaway. Unsubscribe anytime.<br> with the contest. <a id="displayRules" href="javascript:toggle();" style="">Read official rules.</a></p>
		 <p class=""><br><span id="<?php echo $row["giveaway_id"];?>" class="text"><h2>Ending Date:<?php echo $row["giveaway_end_date"]?></h2></span></p>
		 
         <div class="rules" id="toggleRules" style="display:none;">
            <h6 class="headline">Giveaway Rules</h6>
            <ul>
             <li>
			  <p>
				<?php echo $row["giveaway_legal"]?>
			  </p>
				<div class="clear"></div>
              </li>
            </ul>
		</div>
		 <br/>
		 <?php	} 
		?>
		 </div>
		 
		
		 <!-- End Left Column -->
		 
		 <!-- Begin Right Column -->

		 
		 <div id="rightcolumn">
		 <div id="accordion1">
				<div id="navigation" style="">
                    <ul>
                        <li class="selected">
                            <a class="btn1">Email</a>
                        </li>
                        <li>
                            <a class="btn2">Personal sharing</a>
                        </li>
                        <li>
                            <a class="btn3">Visitor Info</a>
                        </li>
                        
                    </ul>
                </div>
		 <div id="step1" >
		 <h3>Step 1</h3>
			 <div id="form1">
					<p id="1">
					<a href="http://www.e27giveaway.10dd.co/"><img class="logo" src="img/giveaway-logo.png"></a>
					<form  enctype="multipart/form-data" method="post"  name="form1" action=""  onsubmit="return validateForm();">
						<ul class="selling-points" style="background:#e7e7e7;padding:15px;-webkit-border-radius: 8px;-moz-border-radius: 8px;border-radius: 8px;border-top:1px rgba(0,0,0,0.08) solid;border-left:1px rgba(0,0,0,0.08) solid;border-bottom:1px rgba(255,255,255,0.45) solid;border-right:1px rgba(255,255,255,0.45) solid;margin-top:18px;">
							<h1>Get More Entries<br>When Friends Enter</h1>
							<li><em style="color: #559DAF; font-weight: 700;">STEP 1</em>: <em>Question</em><em></em> � <a rel="nofollow" style="vertical-align: middle; border: medium none;" href="javascript:void(0);" onclick="" target=""></a><?php echo $giveaway_question; ?>
							<select id="url_giveaways_question" type="text" name="url_giveaways_question" class="text">
								<option value="Byweb">By web</option>
								<option value="human">human</option>
								<option value="Win">Win</option>
								<option value="audi">Audi</option>
							</select></li>	
							
							<li><em style="color: #559DAF; font-weight: 700;">STEP 2</em>: <em>Email</em><em></em> � <a target="" class="" style="vertical-align: middle; border: medium none;" href="" location="contest" ssmsg=""><img src="" style="" height="20" width="55"></a>
							<div class="clear"></div>
							<input id="url_giveaways_email" type="text" name="url_giveaways_email" class="copy" value="" onfocus="if(this.value=="Enter email address")this.value="";" onblur="if(this.value=="")this.value="Enter email address";"/></li>
							<input id="url_old" type="hidden" name="url_old" value="e27giveaways/Kindle_giveaway_by_Amazon"/>
							<div class="clear"></div>
							
							<input  type="submit" value="Submit" class="submit" />
							<!--<input type="hidden" name="src" value="" />-->
							<!--<span class="error" style="dispaly:none">Please enter valid data</span>-->
							<span class="success" style="display:none">uploaded Successfully</span>
						</ul>
					</form>
					</p>
			  </div>
		  
		 </div>
			  
		
		<div id="display"></div>	
	
		  
		  
        
		
		<div id="step3" style="display:none;">
		 <h3>Step 3</h3>
			 <div id="form3">
					<p id="3">
					<a href="http://www.e27giveaway.10dd.co/"><img class="logo" src="img/giveaway-logo.png"></a>
					<form  enctype="multipart/form-data" method="post"  name="form1" action=""  onsubmit="return validateForm();">
						<ul class="selling-points" style="background:#e7e7e7;padding:15px;-webkit-border-radius: 8px;-moz-border-radius: 8px;border-radius: 8px;border-top:1px rgba(0,0,0,0.08) solid;border-left:1px rgba(0,0,0,0.08) solid;border-bottom:1px rgba(255,255,255,0.45) solid;border-right:1px rgba(255,255,255,0.45) solid;margin-top:18px;">
							<h1>Description<br></h1>
							<li><em style="color: #559DAF; font-weight: 700;">*</em>: <em>Visitors</em><em></em> � <a rel="nofollow" style="vertical-align: middle; border: medium none;" href="javascript:void(0);" onclick="" target=""></a>
							</li>	
							
							<li><em style="color: #559DAF; font-weight: 700;">*</em>: <em>Policy</em><em></em> � <a target="" class="" style="vertical-align: middle; border: medium none;" href="" location="contest" ssmsg="">Protecting your privacy hasn�t changed

							Our goal is to provide you with as much transparency and choice as possible, through products like Dashboard and Ads Preferences Manager alongside other tools. Our privacy principles remain unchanged. And we�ll never sell your personal information or share it without your permission (other than rare circumstances like valid legal requests).<img src="" style="" height="20" width="55"></a>
							<div class="clear"></div>
							</li>
							
							<div class="clear"></div>
							
							
						</ul>
					</form>
					</p>
			  </div>
		  
		 </div>
			
		</div>
		</div>		            
			
			
		 <!-- End Right Column -->
		 
		 <!-- Begin Footer -->
		 <!--<div id="footer">
		 Comments
		 <div class="clear"></div>		
		 <!--<div class="fb-comments" data-href="http://e27giveaway.10dd.co" data-num-posts="2" data-width="470"></div>
			
	     </div>-->
		 <!-- End Footer -->
		</div> 
   </div>
   
 </div>  

</div>

   
   <!-- End Wrapper -->
<!-- The JavaScript -->
<script language="javascript">
    function toggle() {
    	var ele = document.getElementById("toggleRules");
    	var text = document.getElementById("displayRules");
    	if(ele.style.display == "block") {
        		ele.style.display = "none";
    		text.innerHTML = "Read official rules.";
      	}
    	else {
    		ele.style.display = "block";
    		text.innerHTML = "Hide the rules.";
    	}
    }
</script>
 
<script type="text/javascript" src="http://code.jquery.com/jquery-1.6.3.min.js"></script>
<script type="text/javascript" src="../../js/transition.js"></script>
<script type="text/javascript" src="../../js/jquery.mousewheel.min.js"></script> <!-- Optional -->
<script type="text/javascript" src="../../js/jquery.easing.1.3.js"></script> <!-- Optional -->
<script type="text/javascript" src="../../js/jquery.slidingtabs.pack.js"></script>
<script type="text/javascript" src="../../js/cufon-yui.js" ></script>
<script type="text/javascript" src="../../js/jClock.js"></script>
<script type="text/javascript" src="../../js/jquery.countdown.js"></script>
<script src="../../js/hubclient.js" async="" type="text/javascript" id="LR1"></script>
<script src="../../js/ga.js" async="" type="text/javascript"></script>
<script src="../../js/widgets.js" async="" type="text/javascript"></script>
<script src="../../js/script.js"></script>  

<script type="text/javascript" src="../../js/jquery.ui.core.js"></script>
<script type="text/javascript" src="../../js/jquery.ui.widget.js"></script>
<script type="text/javascript" src="../../js/jquery.ui.accordion.js"></script>
<script type="text/javascript" src="../../js/fonts/Myriad_Pro_700.font.js"></script>
<script type="text/javascript" src="../../js/fonts/lobster_400.font.js"></script>
<script type="text/javascript" src="../../js/fonts/Franchise_700.font.js"></script>
<script type="text/javascript" src="../../js/fonts/Museo_400.font.js"></script>
<script type="text/javascript" src="../../js/fonts/arvo_400-arvo_700.font.js"></script>
<script type="text/javascript" src="../../js/fonts/myriadreg_400.font.js"></script>
<script type="text/javascript" src="../../js/fonts/helvthin_400.font.js"></script>
<script type="text/javascript" src="../../js/fonts/lane_400.font.js"></script>

<script type="text/javascript">
$(document).ready(function() {
Cufon.replace("h1", { fontFamily: "myriadreg" });
Cufon.replace("h2", { fontFamily: "helvthin" });
Cufon.replace("h3", { fontFamily: "myriadreg" });
Cufon.replace("h4", { fontFamily: "myriadreg" });
Cufon.replace("h5", { fontFamily: "myriadreg" });
Cufon.replace("h6", { fontFamily: "helvthin" });
Cufon.replace("h7", { fontFamily: "myriadreg" });
Cufon.replace("arrow", { fontFamily: "myriadreg" });
Cufon.replace("heading", { fontFamily: "Museo" });
Cufon.replace("museo", { fontFamily: "Museo" });
Cufon.replace("details", { fontFamily: "Myriad Pro" });
Cufon.replace("shadow", { fontFamily: "myriadreg" });
});
</script>
<script type="text/javascript">
$(document).ready(function() {
	$(".tab_content").hide();
	$("ul.tabs li:first").addClass("active").show();
	$(".tab_content:first").show();
	$("ul.tabs li").click(function() {
	    $("ul.tabs li").removeClass("active");
	    $(this).addClass("active");
	    $(".tab_content").hide();
	    var activeTab = $(this).find("a").attr("href");
	    $(activeTab).fadeIn();
	    return false;
	});
});


//JQUERY CLOCK SCRIPT

$(function($) {
  var options = {
    timeNotation: "12h",
    am_pm: true,
    fontFamily:"Myriad Pro",
    fontSize: "13px",
    foreground: "#000",
    //background leftbar #eaeef4 <--
    background: "#eaeef4"
  }
  $("#jclock").jclock(options);
});
</script>
<style type="text/css">
@import "jquery.countdown.css";

#defaultCountdown { width: 300px; height: 91px; color: white;font-family: Helvetica; font-size: 36px; padding-top: 15px;font-stretch: semi-expanded;}
</style>
  
<script src="../../js/jquery.min.js"></script>
<!-- Anything Slider -->
<script src="../../js/jquery.anythingslider.js"></script>
<script src="../../js/jquery.easing.1.2.js"></script> 

<script src="../../js/jquery.countdown.js"></script>
<script src="../../js/script.js"></script>
<!--<link href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/themes/base/jquery-ui.css" rel="stylesheet" type="text/css"/>
<script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/jquery-ui.min.js"></script>-->						
  
</body>
</html>


