
<!DOCTYPE html>
<html>
<head>
<script type="text/javascript" src="http://code.jquery.com/jquery-1.6.3.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
	var userURL_id= $("#userURL_id").val();
	var dataString = "&userURL_id=" + userURL_id;
		//alert("Continue to the step 1.");
		if (userURL_id == "" ) {
          //  alert("alert");
			
			
			
		} else {
			
			$.ajax({
			type:"POST",
			url:"../../Visitor1/theCollector.php",
			data: dataString,
			cache:false,
			success:function(html){
				
				
			}
			});
	}return false;
});
</script>
</head>
<body>
		<form  enctype="multipart/form-data" method="post"  name="form1"  action="" >
			<input id="userURL_id" type="hidden" name="userURL_id" value="194"/>
		</form>
</body>
</html>

 	<?php ob_start();
		
		include("../../Visitor1/theCollector.php");

		//First we need to check if the user has visited before
		//Let"s use "visittime" as the name for our cookie

		if(isset($_COOKIE["visittime"]))
		{
		  echo "Welcome back!<br>";
		  
		  //Calculate how long is since the users last visit
		  //We can do this simply by subtracting the last visit
		  //time from the current time
		  $timeElapsed = time() - $_COOKIE["visittime"];

		  echo "It has been " . $timeElapsed . " seconds since your last visit.";
		}
		else
		{
		  //echo "I see you are new here";
		}

		//Set the current time as a cookie and make it expire much later.
		$nextYear = time() + (60 * 60 * 24 * 365);
		setcookie("visittime", time(), $nextYear);
		 
			error_reporting(E_ALL);
			echo "<meta http-equiv=\"refresh\" content=\"0;url=index.php\" />";
			exit;
			ob_end_flush();			
	?>