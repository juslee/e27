<?
 ob_start();
include('dbcon.php');
if(isset($_POST['userURL_id']))
{
$userURL_id=$_POST['userURL_id'];

session_start();

//select the data in e27giveaway table...
$sql = "SELECT userURL_email FROM userURL WHERE userURL_id = '".$userURL_id."'  ORDER BY userURL_email DESC LIMIT 1";
$res = mysql_query($sql) or die(mysql_error());
$last=mysql_num_rows($res);
if($last==0)
die("No Featured Items!");
$i=0;
while($row = mysql_fetch_array($res))
{
	$userURL_email= $row["userURL_email"];
	$i++;
} 

//collect information...
$browser  =$_SERVER['HTTP_USER_AGENT']; // get the browser name
$curr_page=$_SERVER['PHP_SELF'];// get page name
$ip  =  $_SERVER['REMOTE_ADDR'];   // get the IP address
//$from_page = $_SERVER['HTTP_REFERER'];//  page from which visitor came
$page=$_SERVER['HTTP_REFERER'];//get current page

//Insert the data in the db table and check if ip exists,if exists do not enter,if ip does not exists enter in db_table and increase the userURL_visitor.


$tbCounts = mysql_query("SELECT ip FROM stattracker WHERE ip = '".$ip."' ");
	if(mysql_num_rows($tbCounts) == 0){	
		$query_insert  ="INSERT INTO stattracker(browser,ip,thedate_visited,page,from_page,userURL_id) VALUES('$browser','$ip',now(),'$page','$userURL_email','$userURL_id')" ;
		$result=mysql_query ( $query_insert);
	
	$result_up1 = mysql_query("SELECT from_page FROM stattracker where from_page='$userURL_email'");
		if($result_up1==true){
		  $query_up = "UPDATE userURL SET userURL_visitors=userURL_visitors + 1 WHERE userURL_email = '$userURL_email' AND userURL_id='$userURL_id'";
		  $result_up = mysql_query($query_up);			
		}
	}
}							

?>

<?php ob_end_flush(); ?>