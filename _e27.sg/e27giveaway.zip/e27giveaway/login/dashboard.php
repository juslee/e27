<?php include('../lib/dbcon.php'); include('../lib/functions.php'); include("../classes/class.acl.php"); 

$myACL = new ACL();
if ($myACL->hasPermission('access_dashboard') != true)
{
	//header("location: noentry.php");
}
$session  = $_SESSION['userID'];
$loggedas = $myACL->getUsername($session);

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>E27 Dashboard</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php include('../lib/scripts.php');?>
<script type="text/javascript">
$(function(){
	$("a.dash").addClass("active");
});
</script>
<script type="text/javascript" src="../js/jquery.js"></script>
<script type="text/javascript">
$(document).ready(function(){
//table Filter 
$('#dashboard').tableFilter({
         // additionalFilterTriggers: [$('#test-filter')]
}) 
 
$('.btn2').click(function(){
$(".display").hide();
});
 //bottom table ajax generation.When click on the show button down table will generate from this.
 $('.btn1').live("click",function(){
	var id=$(this).attr("id");
	//alert(id);
	var dataString = '&id='+id ;
	//$(".display").hide();
	//alert(dataString);
	$.ajax({
	type: "POST",
    url: "table_insert.php",
    data: dataString,
    success: function(data){
	$("#email_table").html(data);
	}
});

	return false;
	});
});
</script>

</head>

<body id="login">

<div id="wrapper">
	<?php include('../lib/left_bar.php');?>
	
	<div id="content_main" style="background-color:rgb(240,240,240);"> 
		<!-- ======================================== RIGHT CONTENT ============================ -->
		
		<div id="dashboard_header">
			<h2>Dashboard</h2><h3>Current Giveaway Leaderboard</h3>
		</div>

		<a href="CMS.php" id="dashboard_creategiveaway">Create Giveaway</a>
			<!--<div id="page">
				<h2>Dashboard</h2></br>
				<a href="../login/task_index.php">Task</a>
				<p>You are logged in as <?php echo $loggedas; ?></p>
			</div>--> <!-- close page -->
			<div class="clear"></div>
		<div id="statistics" ><!--stat table-->
			<table width="90%" border="1" style="border-collapse:collapse;background-color:#FFFFFF;border-width:1px;border-style:solid;border-color:#F0F0F0;" id="dashboard">
			  <thead style="border-collapse:collapse;background-color:#FFFFFF;border-width:1px;border-style:solid;border-color:#F0F0F0;"><tr>
				<th width="30%" style="border-color:#F0F0F0;" ><h6><strong>Giveaway </strong></h6></th>
				<th width="15%" style="border-color:#F0F0F0;" filter='false'><h6><strong>Ending </strong></h6></th>
				<th width="45%" style="border-color:#F0F0F0;" filter='false'><h6><strong>Current Leader </strong></h6></th>
			  </tr></thead>
			   <?php 
			  	$query = "select DISTINCT giveaway_id from giveaway";
				
		        $result = mysql_query($query);
				$t=1;
		        // for each column, this loop gets the content based on the giveaway_name field result in the fetched array.
				while(list($giveaway_id)= mysql_fetch_row($result))
		        {
					//$query_details = "SELECT giveaway.giveaway_id, giveaway.giveaway_name, giveaway.giveaway_end_date, userURL.userURL_id, userURL.giveaway_id, userURL.userURL_email, userURL.userURL_visitors FROM giveaway INNER JOIN userURL ON giveaway.giveaway_id = userURL.giveaway_id WHERE giveaway.giveaway_id = '$giveaway_id'";
					//$result1 = mysql_query($query_details);
					$query_details = "SELECT giveaway.giveaway_name, giveaway.giveaway_end_date,giveaway.giveaway_id, userURL.userURL_email, userURL.userURL_visitors FROM giveaway INNER JOIN userURL ON giveaway.giveaway_id = userURL.giveaway_id WHERE giveaway.giveaway_id = '$giveaway_id' order by userURL.userURL_visitors DESC limit 1 ";
					$result1 = mysql_query($query_details);
					
					while($row = mysql_fetch_array($result1))
					{
						$giveaway_id = $row['giveaway_id'];
						$giveaway_name = $row['giveaway_name'];
						$user_email = $row['userURL_email'];
						$giveaway_end_date = $row['giveaway_end_date'];
						$visitors = $row['userURL_visitors'];
						
				?>
					
			  <tr valign="top"  id='<? echo $giveaway_id; ?>'>
				<td style="border-color:#F0F0F0;"><h7 style="font-size:14px; color:black;"><? echo $t.".&nbsp".$giveaway_name; ?></h7></td>
				<td style="border-color:#F0F0F0 ;"><h7 style="font-size:14px; color:black;"><? echo $giveaway_end_date; ?></h7></td>
				<td style="border-color:#F0F0F0;"><h7><a style="font-size:14px; color:black;" href="mailto: <? echo $user_email; ?>"><? echo $user_email; ?> (<? echo $visitors; ?> visitors)</a></h7>
				<a href="#" id="<? echo $giveaway_id; ?>" class="btn1" style="float:right; "></a></td>
			  </tr>
			  	<?php									
					$t++;}
				}
	            ?>
			</table>
		
			<!--Success function return html-->
			<div class="display">
				<table  border="1" width="90%" id="email_table" style="border-collapse:collapse;background-color:#FFFFFF;border-width:1px;border-style:solid;border-color:#f0f0f0; font-size:14px;color:black;" >
				</table>
			</div>
		</div> <!-- close statistics -->
	</div> <!-- close content_main -->
		
</div> <!-- close wrapper -->
</body>
</html>