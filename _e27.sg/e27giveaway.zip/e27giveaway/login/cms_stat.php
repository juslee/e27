<?php

include('../lib/dbcon.php');
//CMS li stat button post and loop generation.
if(isset($_POST['id'])){
   $id=$_POST['id'];
   

			  	$query = "select DISTINCT giveaway_id from giveaway where giveaway_id='$id' ";
				
		         $result = mysql_query($query);
		        // for each column, this loop gets the content based on the stat_name field result in the fetched array.
				while(list($giveaway_id)= mysql_fetch_row($result))
		        {
					$query_details = "SELECT giveaway.giveaway_name, giveaway.giveaway_end_date,giveaway.giveaway_id, userURL.userURL_email, userURL.userURL_visitors FROM giveaway INNER JOIN userURL ON giveaway.giveaway_id = userURL.giveaway_id WHERE giveaway.giveaway_id = '$id' order by userURL.userURL_visitors DESC limit 1 ";
					$result1 = mysql_query($query_details);
					while($row = mysql_fetch_array($result1))
					{
						$giveaway_id = $row['giveaway_id'];
						$giveaway_name = $row['giveaway_name'];
						$user_email = $row['userURL_email'];
						$giveaway_end_date = $row['giveaway_end_date'];
						$visitors = $row['userURL_visitors'];
					}
						
				}	echo '<div style=color:#406137;text-align:left;font-size:14px;font-style:inherit; >'.'Statistic Details'.'<br></div>';	   
				  echo '<div style=color:#ED212F;text-align:left;font-size:14px;font-style:inherit; >'.$giveaway_name.'<br>';
				  echo $user_email.'<br>';
				  echo $visitors.'</div>';
  
}
?>




