<?php 
include("../../lib/dbcon.php"); 
include("../../classes/class.acl.php");
/*
$myACL = new ACL();
if ($myACL->hasPermission('access_admin') != true)
{
	header("location: ../login/noentry.php");
}
*/
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>ACL</title>
<link href="../../styles/styles_24.css" rel="stylesheet" type="text/css" />

<script type="text/javascript" >
$(function(){
	$("a.useradmin").addClass("active");
	$("a.user_admin").addClass("active1");
});
</script>
</head>


<body id="login">
<div id="wrapper">
	<?php include('../../lib/left_bar.php');?>
	
	<div id="content_main"> 
		<!-- ======================================== RIGHT CONTENT ============================ -->
		<div id="left_content">
			<div id="left_header" class="usermanagement">
				<ul id="submenutop">
					<li><a href="../login_index.php" class="home">Home</a></li>
					<li><a href="" class="new">New User</a></li>
					<li><a href="users.php" class="users_manage">Users</a></li>
					<li><a href="roles.php" class="roles">Roles</a></li>
					<li><a href="perms.php" class="permissions">Permissions</a></li>
					<li><a href="" class="user_admin">User Admin</a></li>
				</ul>
			</div>
			<div class="clear"></div>
			<div id="page">
			    <h3 style="color:#474647";>Click buttons above to navigate.</h3>
			    
			</div>	
		</div>
		
		
		<!-- ======================================== RIGHT CONTENT ============================ -->
		<div id="right_content">
		
		
			<div class="clear"></div>
		</div>
		<div class="clear"></div>
	</div>
	
	<div id="right_bar">right</div>
</div> <!-- close wrapper -->

</body>
</html>