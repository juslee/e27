<?php

include("../lib/dbcon.php"); 

if(isset($_GET['modify'])){
$modify=($_GET['modify']);
//look up the record based on modify and get the giveaway_id,giveaway_name etc..
$field = mysql_query("SELECT * FROM giveaway where giveaway_id='$modify' ");


while($row=mysql_fetch_array($field))
{


$giveaway_id				=$row['giveaway_id'];
$giveaway_name				=$row['giveaway_name'];
$giveaway_description		=$row['giveaway_description'];
$giveaway_benefits			=$row['giveaway_benefits'];
$giveaway_prize_description	=$row['giveaway_prize_description'];
$giveaway_question			=$row['giveaway_question'];
$giveaway_start_date		=$row['giveaway_start_date'];
$giveaway_end_date			=$row['giveaway_end_date'];
$giveaway_legal				=$row['giveaway_legal'];


//build the JSON array for return
$json = array(array('field' => 'giveaway_name',
'value' => $giveaway_name),
array('field' => 'giveaway_description',
'value' => $giveaway_description),
array('field' => 'giveaway_benefits',
'value' => $giveaway_benefits),
array('field' => 'giveaway_prize_description',
'value' => $giveaway_prize_description),
array('field' => 'giveaway_question',
'value' => $giveaway_question),
array('field' => 'giveaway_start_date',
'value' => $giveaway_start_date),
array('field' => 'giveaway_end_date',
'value' => $giveaway_end_date),
array('field' => 'giveaway_legal',
'value' => $giveaway_legal),
array('field' => 'giveaway_id',
'value' => $giveaway_id)
);

echo json_encode($json );

}
}
?>


