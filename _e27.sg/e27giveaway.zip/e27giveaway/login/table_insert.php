<?php
include('../lib/dbcon.php'); 
//Dashboard bottom table generation.
if(isset($_POST['id']))
{
$id=$_POST['id'];

	$query_details = "SELECT * from userURL where giveaway_id='$id' ";
				$result1 = mysql_query($query_details);
				
		echo "<table style='background-color:#FFFFFF;'>";		
			echo"<tr>";
				//echo"<th width='16%' style='border-color:#F0F0F0;'><h6 style='font-size:20px;font-weight:normal;'></h6></th>";
				echo"<th width='6%' style='border-color:#F0F0F0;'><h6 style='font-size:20px;font-weight:normal;'>Current Leader</h6></th>";
				echo"<th width='1%' style='border-color:#F0F0F0;'><h6 style='font-size:20px;font-weight:normal;'>Visitors</h6></th>";
				echo"<th width='30%' style='border-color:#F0F0F0;'><h6 style='font-size:20px;font-weight:normal;'>Visitors Url</h6></th>";
				
			echo"</tr>";
			
				$t=1;
				while($row = mysql_fetch_array($result1))
				{
					  $row['giveaway_id']; 
					  $row['userURL_email'];
					  $row['userURL_visitors'];
					  $row['userURL_address'];
					  
					
			echo "<tr style='height: 30px; line-height: 30px;'>";
				//echo"<td  style='border-color:#F0F0F0;'><h7 style='font-size:14px; color:#000000;'></h7></td>";
				echo"<td  style='border-color:#F0F0F0;'><h7 style='font-size:14px; color:#000000;'>$t.&nbsp".$row['userURL_email']."</h7></td>";
				echo"<td  style='border-color:#F0F0F0;'><h7 style='font-size:14px; color:#000000;'>".$row['userURL_visitors']."</h7></td>";
				echo"<td  style='border-color:#F0F0F0;'><h7 style='font-size:14px; color:#000000;'>".$row['userURL_address']."</h7></td>";
			echo "<tr>";
			

					
				$t++;
				}

echo "</table>";
}				
?>

