<?php 
include("../lib/dbcon.php"); 
include("../classes/class.acl.php");
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>CMS Page</title>
<link href="../styles/form.css" rel="stylesheet" type="text/css" />
<?php include('../lib/scripts.php');?>
</head>
<body id="login">

<div id="wrapper">
	<?php include('../lib/left_bar.php');?>
	
	<div id="content_main"> 
		<div id="dashboard_header">
			<h2>Giveaway Management</h2><h3>Create. Edit. Delete Giveaways</h3>
		</div>
		
		<!-- ======================================== LEFT CONTENT ============================ -->
		<div id="left_content">
			<ul id="task_list">
			<div id="display"></div><!--giveaway_CMS li list generation and success function html return.-->
			<?php
				$result = mysql_query("SELECT * FROM giveaway order by giveaway_id desc");
					while($row = mysql_fetch_array($result)) {
				  
				  echo "<li class='record'>".$row['giveaway_name']." <a href="	.$row['giveaway_url'] . " class='linkbutton' >" .$row['giveaway_url']."</a><a href='#' id=".$row['giveaway_id']." class='delbutton'></a><a href='#' id=".$row['giveaway_id']." class='edit'></a>
				  <a href='#' id=".$row['giveaway_id']." class='edit2'></a></li>"; 
				  
				  
				  ?>
				  
			<?php				  
				}
			?>
			</ul>
			<div class="clear"></div>
		</div>
		
		
		<!-- ======================================== RIGHT CONTENT ============================ -->
		<div id="right_content">
			<div id="form">
				<form id="target" enctype="multipart/form-data" method="post" name="form" action="" >
					<ul id="form_ul">
						<!-- <li><label for="Field1"></label></li> -->
						<h2 style="margin-left:20px;">Input Data</h2><br>
						<li>
							<label for="giveaway_name">Giveaway Name</label> 
							<input id="giveaway_name" type="text" name="giveaway_name" class="CMS field text" tabindex="1" title="Please don't enter the same name twice."/>
							<div class="clear"></div>
						</li>
						<li>
							<label for="giveaway_description">Description</label>
							<textarea id="giveaway_description" type="text" name="giveaway_description" class="CMS field text" tabindex="2" ></textarea>
							<div class="clear"></div>
						</li>
						<li>
							<label for="giveaway_prize_description">Prize Description</label> 
							<textarea id="giveaway_prize_description" type="text" name="giveaway_prize_description" class="CMS field text" tabindex="3" ></textarea>
							<div class="clear"></div>
						</li>
						<li>
							<label for="giveaway_question">Question</label> 
							<input id="giveaway_question" type="text" name="giveaway_question" class="CMS field text" tabindex="4"/>
							<div class="clear"></div>
						</li>
						<li>
							<label class="start_date_field" for="giveaway_start_date">Start date</label>
							<input id="giveaway_start_date" name="giveaway_start_date" type="text" class="CMS field text" tabindex="5" />
							<div class="clear"></div></li>
						<li>
							<label class="end_date_field" for="giveaway_end_date">End date</label>
							<input id="giveaway_end_date" type="text" name="giveaway_end_date" class="CMS field text" tabindex="6" />
							<div class="clear"></div>
						</li>
						<li>
							<label for="giveaway_legal">Legal</label>
							<textarea id="giveaway_legal" type="text" name="giveaway_legal" class="CMS field text" tabindex="7" ></textarea>
							<div class="clear"></div>
						</li>
						<li>
							<label for="giveaway_benefits">Notes (will not be published)</label> 
							<textarea id="giveaway_benefits" type="text" name="giveaway_benefits" class="CMS field text" tabindex="8" ></textarea>
							<div class="clear"></div>
						</li>
						<li>
							<input id="giveaway_id" type="hidden" name="giveaway_id" class="CMS field text" tabindex="9" value="" />
						</li>
						<li style="position:relative; right:-253px;">
							<input type="submit" class="submit" name="submit" id="submit" value="" />
							<input style="display:none;" type="submit" class="update" name="update" id="update" value="update"/>
						</li>
						<br><br>
					</ul>
				</form>
			</div> <!-- close form -->
			<div id="flash"></div>
		</div> <!-- close right_content -->
		<div class="clear"></div>
	</div> <!-- close content_main -->
	<div id="right_bar" >
		<div id="right_bar_stat" style="display:none;">
	</div>
	</div>
</div> <!-- close wrapper --> 

<!--Script for the jquery-UI and javascript edit,submit,del and update buttons.-->
<script type="text/javascript">
$(document).ready(function() {


$(".edit").live("click", function(){
 $("label").fadeOut();
 $("#update").fadeIn();
 $('#submit').fadeOut();
 var test = $(this).attr('id');
 
 var giveaway_name = $("#giveaway_name").val();
 var giveaway_description = $("#giveaway_description").val();
 var giveaway_benefits = $("#giveaway_benefits").val();
 var giveaway_prize_description = $("#giveaway_prize_description").val();
 var giveaway_question = $("#giveaway_question").val();
 var giveaway_start_date = $("#giveaway_start_date").val();
 var giveaway_end_date = $("#giveaway_end_date").val();
 var giveaway_legal = $("#giveaway_legal").val();
 

//pass name_variable to the json_data.php.
$.getJSON("json_data.php?modify="+ $(this).attr('id'),function(data){

$.each(data, function(i,item){

if (item.field == "giveaway_name") {
$("#giveaway_name").val(item.value);
}else if (item.field == "giveaway_description") {
$("#giveaway_description").val(item.value);
}else if (item.field == "giveaway_benefits") {
$("#giveaway_benefits").val(item.value);
} else if (item.field == "giveaway_prize_description") {
$("#giveaway_prize_description").val(item.value);
}else if (item.field == "giveaway_question") {
$("#giveaway_question").val(item.value);
}else if (item.field == "giveaway_start_date") {
$("#giveaway_start_date").val(item.value);
}else if (item.field == "giveaway_end_date") {
$("#giveaway_end_date").val(item.value);
}else if (item.field == "giveaway_legal") {
$("#giveaway_legal").val(item.value);
}else if (item.field == "giveaway_id") {
$("#giveaway_id").val(item.value);
}
});
		
	});
});
});
//jquery-UI datepicker.
$(function() {
	$('#giveaway_start_date').datepicker({
		showOn: 'both',
		buttonImage: "cal.png",
		buttonImageOnly: true,
		autoSize: true,
		onSelect: function (dateText, inst) {
			$('.start_date_field').empty();
			$(this).parent('form').submit();
		}
	});



	$('#giveaway_end_date').datepicker({
		showOn: 'both',
		buttonImage: "cal.png",
		buttonImageOnly: true,
		autoSize: true,
		onSelect: function (dateText, inst) {
			$('.end_date_field').empty();
			$(this).parent('form').submit();
		}
	});

//submit button ajax generation.

$(".submit").click(function() {
	
	var giveaway_id 				= $("#giveaway_id").val();
	var giveaway_name 				= $("#giveaway_name").val();
	var giveaway_description 		= $("#giveaway_description").val();
	var giveaway_benefits 			= $("#giveaway_benefits").val();
	var giveaway_prize_description 	= $("#giveaway_prize_description").val();
	var giveaway_question 			= $("#giveaway_question").val();
	var giveaway_start_date			= $("#giveaway_start_date").val();
	var giveaway_end_date 			= $("#giveaway_end_date").val();
	var giveaway_legal 				= $("#giveaway_legal").val();
	
    var dataString = '&giveaway_name='+giveaway_name +'&giveaway_description='+giveaway_description+'&giveaway_benefits='+giveaway_benefits+'&giveaway_prize_description='+giveaway_prize_description+'&giveaway_question='+giveaway_question+'&giveaway_start_date='+giveaway_start_date+'&giveaway_end_date='+giveaway_end_date+'&giveaway_legal='+giveaway_legal;
	if(giveaway_name=='' || giveaway_description=='')
	{
	
	alert("please Enter Some text");
	$('.success').fadeOut(200).hide();
	$('.error').fadeOut(200).show();
	}
	else
	{
	$.ajax({
	type: "POST",
    url: "../ga/join_template.php",
    data: dataString,
    success: function(html){
	$("#display").after(html);
	$('.success').fadeIn(200).show();
	$('.submit').hide();
	$('.update').show();
    $('.error').fadeOut(200).hide();
	$('#giveaway_name').val('');
	$('#giveaway_description').val('');
	$('#giveaway_benefits').val('');
	$('#giveaway_prize_description').val('');
	$('#giveaway_question').val('');
	$('#giveaway_start_date').val('');
	$('#giveaway_end_date').val('');
	$('#giveaway_legal').val('');
	document.getElementById('giveaway_name').value='';
	document.getElementById('giveaway_name').focus();	
   }
});
}
return false;
});


<!--giveaway_del-->

	$(".delbutton").live("click",function(){
		var del_id = $(this).attr("id");
		var info = 'id=' + del_id;
		if(confirm("Sure you want to delete this update? There is NO undo!")) {
			$.ajax({
				type: "POST",
				url: "../lib/giveaway_delete.php",
				data: info,
				success: function(){
				}
			});
			$(this).parents("li.record").fadeOut(400);
		}
	return false;
	});

<!--giveaway_update-->
$(".update").click(function() {

	var giveaway_id 				= $("#giveaway_id").val();
	var giveaway_name 				= $("#giveaway_name").val();
	var giveaway_description 		= $("#giveaway_description").val();
	var giveaway_benefits 			= $("#giveaway_benefits").val();
	var giveaway_prize_description 	= $("#giveaway_prize_description").val();
	var giveaway_question 			= $("#giveaway_question").val();
	var giveaway_start_date			= $("#giveaway_start_date").val();
	var giveaway_end_date 			= $("#giveaway_end_date").val();
	var giveaway_legal 				= $("#giveaway_legal").val();
	
	var dataString ='&giveaway_id='+giveaway_id+'&giveaway_name='+giveaway_name+'&giveaway_description='+giveaway_description+'&giveaway_benefits='+giveaway_benefits+'&giveaway_prize_description='+giveaway_prize_description+'&giveaway_question='+giveaway_question+'&giveaway_start_date='+giveaway_start_date+'&giveaway_end_date='+giveaway_end_date+'&giveaway_legal='+giveaway_legal;
	
	if(giveaway_name=='' || giveaway_description=='')
	{
	alert("please Enter Some text");
	}
	else
	{
	$.ajax({
	type: "POST",
    url: "../lib/giveaway_update.php",
    data: dataString,
    success: function(){
	
	$('#giveaway_name').val('');
	$('#giveaway_description').val('');
	$('#giveaway_benefits').val('');
	$('#giveaway_prize_description').val('');
	$('#giveaway_question').val('');
	$('#giveaway_start_date').val('');
	$('#giveaway_end_date').val('');
	$('#giveaway_legal').val('');
	
	
   }
});
}
	return false;
	});

//autoGrow and inFieldLabels.
jQuery(function($){
	//$(".field").Watermark("Type something!");
	$(".field").autoGrow();
	$("label").inFieldLabels();
});
//CMS stat button ajax generation.
$(".edit2").live("click", function(){

var del_id = $(this).attr("id");
		var datastring = '&id=' + del_id;
		
		$.ajax({
			type: "POST",
			url:"cms_stat.php",
			data: datastring,
			success:function(data){
				balance=data;
				
				$('#right_bar_stat').html(balance);
				$('#right_bar_stat').fadeIn(400).delay(4000).fadeOut(400);
				}
		});		
				
});

});
</script>
<!--giveaway_CMS jquery-ui.css and jquery-ui.min.js for the datepicker and other ui elements.-->
<link href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/themes/base/jquery-ui.css" rel="stylesheet" type="text/css"/>
<script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/jquery-ui.min.js"></script>						

</body>
</html>