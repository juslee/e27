<?php 
include("../lib/dbcon.php"); 
include("../classes/class.acl.php");

$myACL = new ACL();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>User Management Panel - e27giveaway</title>
<link href="../../styles/styles_24.css" rel="stylesheet" type="text/css" />
<?php// include('../lib/scripts.php');?>
<script type="text/javascript" >
$(function(){
	$("a.useradmin").addClass("active");
	$("a.home").addClass("active1");
});
</script>
</head>


<body id="login">

<div id="wrapper">
	<?php include('../lib/left_bar.php');?>
	
	
	<div id="content_main"> 
		<!-- ======================================== RIGHT CONTENT ============================ -->
		<div id="left_content" >
			<div id="left_header" class="usermanagement">
				<ul id="submenutop">
					<li><a href="" class="home">Home</a></li>
					<li><a href="" class="new">New User</a></li>
					<li><a href="admin/users.php" class="users_manage">Users</a></li>
					<li><a href="admin/roles.php" class="roles">Roles</a></li>
					<li><a href="admin/perms.php" class="permissions">Permissions</a></li>
					<li><a href="admin/admin_index.php" class="user_admin">User Admin</a></li>
				</ul>
			</div>
			<div class="clear"></div>
			<div id="page">
			 <h3 style="color:#474647";>Permissions for </h3>
			<? 
				$userACL = new ACL($userID);
				$aPerms = $userACL->getAllPerms('full');
				foreach ($aPerms as $k => $v)
				{
					echo "<strong>" . $v['Name'] . ": </strong>";
					echo "<img src=\"../img/";
					if ($userACL->hasPermission($v['Key']) === true)
					{
						echo "allow.png";
						$pVal = "Allow";
					} else {
						echo "deny.png";
						$pVal = "Deny";
					}
					echo "\" width=\"16\" height=\"16\" alt=\"$pVal\" /><br />";
				}
			?>
		    <h3 style="color:#474647";>Change User:</h3>
		    <? 
				$strSQL = "SELECT * FROM `users` ORDER BY `users_username` ASC";
				$data = mysql_query($strSQL);
				while ($row = mysql_fetch_assoc($data))
				{
					echo "<a href=\"?userID=" . $row['users_id'] . "\">" . $row['users_username'] . "</a><br />";
				}
		    ?>
		    </div> <!-- close page -->
		</div> <!-- close left_content -->
		
		
		<!-- ======================================== RIGHT CONTENT ============================ -->
		<div id="right_content">
			
						
			<div class="clear"></div>
		</div>
		<div class="clear"></div>
	</div>
	
	
	<div id="right_bar">right</div>
</div> <!-- close wrapper -->


</body>
</html>