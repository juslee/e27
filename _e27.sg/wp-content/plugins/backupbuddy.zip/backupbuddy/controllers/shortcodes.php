<?php

class pb_backupbuddy_shortcodes extends pluginbuddy_shortcodescore {
	
	
	
}
?>